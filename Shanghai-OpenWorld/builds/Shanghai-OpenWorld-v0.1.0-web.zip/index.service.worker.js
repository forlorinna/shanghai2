'use strict';
const prefix = 'shanghai-open-world:' + self.registration.scope + ':';
const name = prefix + "e127c99ff0396e4d";
const assets = ["index.144x144.png", "index.180x180.png", "index.512x512.png", "index.apple-touch-icon.png", "index.audio.position.worklet.js", "index.audio.worklet.js", "index.html", "index.icon.png", "index.js", "index.manifest.json", "index.offline.html", "index.pck", "index.png", "index.wasm"];
const allowed = new Set(assets.map(file => new URL(file, self.registration.scope).href));
self.addEventListener('install', event => {
  event.waitUntil(caches.open(name).then(cache => cache.addAll(assets)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith(prefix) && key !== name).map(key => caches.delete(key))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  url.hash = '';
  url.search = '';
  const key = url.href === self.registration.scope ?
    new URL('index.html', self.registration.scope).href : url.href;
  if (!allowed.has(key)) return;
  event.respondWith(caches.open(name).then(cache => cache.match(key))
    .then(response => response || fetch(event.request)));
});
